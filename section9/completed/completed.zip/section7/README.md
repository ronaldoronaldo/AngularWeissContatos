# Learn Real World AngularJS Step By Step by CodeCraft
http://codecraftpro.com

## Section 7 - Create template functions with Filters

# Folders
./libs/ - The required libraries for all lectures in this section.
./lesson1 - Starter template for all lectures in this section
./completed - The completed application for this section